<?php

namespace App\Constants;

class Status
{
    public const DRAFT = 'draft';
    public const PUBLISHED = 'published';
    public const UNPUBLISHED = 'unpublished';
}
