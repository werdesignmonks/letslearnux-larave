<?php

namespace App\Constants;

class Role
{
    public const ADMIN = 'admin';
    public const USER = 'user';
}
