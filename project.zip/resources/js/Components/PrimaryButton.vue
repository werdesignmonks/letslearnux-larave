<template>
    <button
        class="block w-full px-4 py-3 bg-dm-color-primary text-base rounded-3xl font-medium -tracking-[0.5px] text-white hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150"
    >
        <slot />
    </button>
</template>
