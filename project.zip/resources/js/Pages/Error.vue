<script setup>

</script>

<template>

    <h1>
        Error 404
    </h1>
</template>

<style scoped>

</style>
