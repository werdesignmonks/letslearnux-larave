<script setup>

</script>

<template>
    <div class="w-[850px] h-[616px] bg-white rounded-lg border border-neutral-200 flex-col justify-start items-start inline-flex">
        <div class="self-stretch bg-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] h-14 px-5 py-6 justify-start items-center flex">
                <div class="text-zinc-700 text-sm font-medium leading-tight">Rank</div>
            </div>
            <div class="w-80 h-14 px-5 py-6 justify-start items-center flex">
                <div class="text-zinc-700 text-sm font-medium leading-tight">Contributor</div>
            </div>
            <div class="w-[82px] h-14 px-5 py-6 justify-start items-center flex">
                <div class="text-zinc-700 text-sm font-medium leading-tight">Book</div>
            </div>
            <div class="w-[82px] h-14 px-5 py-6 justify-start items-center flex">
                <div class="text-zinc-700 text-sm font-medium leading-tight">Article</div>
            </div>
            <div class="grow shrink basis-0 h-14 px-5 py-6 justify-start items-center flex">
                <div class="text-zinc-700 text-sm font-medium leading-tight">Video</div>
            </div>
            <div class="w-28 h-14 px-5 py-6 justify-start items-center flex">
                <div class="text-zinc-700 text-sm font-medium leading-tight">Total</div>
            </div>
        </div>
        <div class="self-stretch h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 h-8 relative">
                    <div class="left-[14px] top-[19px] absolute text-gray-950 text-[10px] font-bold leading-[10px]">1</div>
                </div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Arlene McCoy</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 h-8 relative">
                    <div class="left-[14px] top-[19px] absolute text-gray-950 text-[10px] font-bold leading-[10px]">2</div>
                </div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Wade Warren</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 h-8 relative">
                    <div class="left-[14px] top-[19px] absolute text-gray-950 text-[10px] font-bold leading-[10px]">3</div>
                </div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Ralph Edwards</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 text-center text-slate-600 text-base font-normal leading-relaxed">4</div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Devon Lane</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 text-center text-slate-600 text-base font-normal leading-relaxed">5</div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Floyd Miles</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 text-center text-slate-600 text-base font-normal leading-relaxed">6</div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Jenny Wilson</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 text-center text-slate-600 text-base font-normal leading-relaxed">7</div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Esther Howard</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 text-center text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Annette Black</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 text-center text-slate-600 text-base font-normal leading-relaxed">9</div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Arlene McCoy</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
        <div class="w-[849px] h-14 py-2 border-t border-neutral-200 justify-start items-start inline-flex">
            <div class="w-[82px] self-stretch px-5 justify-start items-center flex">
                <div class="w-8 text-center text-slate-600 text-base font-normal leading-relaxed">10</div>
            </div>
            <div class="w-80 self-stretch px-5 justify-start items-center gap-2 flex">
                <img class="w-7 h-7 rounded-full" src="https://via.placeholder.com/28x28" />
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">Brooklyn Simmons</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">18</div>
            </div>
            <div class="w-[82px] self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">13</div>
            </div>
            <div class="grow shrink basis-0 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">8</div>
            </div>
            <div class="w-28 self-stretch px-5 justify-start items-center gap-2 flex">
                <div class="grow shrink basis-0 text-slate-600 text-base font-normal leading-relaxed">39</div>
            </div>
        </div>
    </div>
</template>

<style scoped>

</style>
