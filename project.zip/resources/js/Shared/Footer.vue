<script setup>
import { Link } from '@inertiajs/vue3'

</script>

<template>
    <footer class="border-t-[1px] border-dm-border-color">
        <div class="container mx-auto px-4 py-6">
            <div class="flex flex-wrap justify-between items-center">
                <div class="w-full text-center">
                    <p class="text-sm text-gray-500">© 2023, <Link href="https://www.designmonks.com/" class="hover:text-dm-color-primary">Design Monks</Link> . All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>
</template>
